<!DOCTYPE html>
<html>
<head>
	<title>404 Page Not Found</title>
	<link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/bootstrap.min.css">
	<style> body{ background: url(<?php echo base_url();?>assets/img/404.png); background-size:100%; background-repeat: no-repeat; width: 100%; } </style>
</head>
<body>
	<!-- <audio id="player" style="display:none;" autoplay controls ><source src="<?php //echo base_url("assets/");?>20210215_-1446245723202169827.mp3" type="audio/mp3" ></audio> -->
	<div class="container-fluid">
		<div class="row">
		<a class="btn btn-danger" href="<?php echo base_url('Home/index');?>" style="margin:10px;">Go to Homepage</a>
		</div>
	</div>
</body>

</html>