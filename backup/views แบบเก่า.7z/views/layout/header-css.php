      <!-- basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- mobile metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/bootstrap.min.css">
    <!-- style css -->
    <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/style.css">
    <!-- Responsive-->
    <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/responsive.css">
    <!-- Scrollbar Custom CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>fontawesome-free-5.15.1/css/all.min.css">
    <!-- owl stylesheets -->
    <link rel="stylesheet" href="<?php echo base_url('assets/'); ?>css/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
    <link href ="<?php echo base_url('assets/'); ?>myCSS.css" rel="stylesheet">
    <script src="<?php echo base_url('assets/') ?>js/jquery.min.js"></script>
    <script src="<?php echo base_url('assets/') ?>js/bootstrap.min.js"></script>
    <script src="<?php echo base_url('assets/') ?>js/popper.min.js"></script>

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
