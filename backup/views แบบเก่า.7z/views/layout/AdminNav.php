<!-- Topbar -->
<nav class="navbar navbar-expand navbar-light topbar static-top shadow">
    <!-- Topbar Navbar -->
    <div class="navbar-nav ml-auto">
        <span class="mr-2 d-lg-inline PacificoFN" style="font-size: 200%; color:#1CC88A;">Kaaikong</span>          
    </div>

</nav>
<!-- End of Topbar -->